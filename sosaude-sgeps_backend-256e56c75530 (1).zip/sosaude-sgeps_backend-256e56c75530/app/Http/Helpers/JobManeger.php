<?php
namespace App\Http\Helpers;

use App\Models\User;
use Illuminate\Support\Facades\Mail;

class JobManeger
{
    /* public static function sendResetPassword(User $recipient, $hash)
    {
        SendResetPasswordJob::dispatch($recipient, $hash);
    } */
}